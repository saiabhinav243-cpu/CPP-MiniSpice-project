# MiniSPICE GUI integration

This version keeps the uploaded MiniSPICE backend source files unchanged and
adds a GUI entry point based on the provided ZIP frontend.

## New files

- `main_GUI.cpp` — GUI application adapted from the ZIP frontend.
- `gui_backend_bridge.h/.cpp` — connects the GUI netlist to the existing
  `Circuit`/`Component` structure and performs MNA for the GUI.
- `CMakeLists.txt` — builds the GUI against Qt6 and Eigen3.

The original ZIP frontend is retained under `zip_frontend_original/`.

## Build

From this directory:

```bash
cmake -S . -B build
cmake --build build --config Release
```

On Windows with a Qt6 installation available to CMake, the executable will be
under `build/Release/MiniSPICE_GUI.exe` for a Visual Studio generator or the
corresponding build directory for another generator.

## Netlist examples

```text
V1 1 0 1
R1 1 2 1k
C1 2 0 1u
```

AC source syntax supported by the GUI bridge:

```text
V1 1 0 AC 1 0
```

where the final number is the phase in degrees.
