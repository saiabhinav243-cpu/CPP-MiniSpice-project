#include "gui_backend_bridge.h"

#include "circuit.h"
#include "component.h"

#include <Eigen/Dense>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <complex>
#include <iomanip>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

using Complex = std::complex<double>;

// GUI-only voltage source. This leaves the uploaded Component/VoltageSource
// classes untouched while allowing the GUI netlist to express AC magnitude
// and phase.
class GuiVoltageSource final : public Component {
public:
    GuiVoltageSource(const std::string& n, int a, int b,
                     double dcVoltage,
                     double acMagnitude,
                     double acPhaseDeg,
                     bool explicitAC,
                     bool explicitDC)
        : Component(n, a, b),
          dcVoltage_(dcVoltage),
          acMagnitude_(acMagnitude),
          acPhaseDeg_(acPhaseDeg),
          explicitAC_(explicitAC),
          explicitDC_(explicitDC) {}

    Complex getImpedance(double) const override { return {0.0, 0.0}; }
    double getValue() const override { return dcVoltage_; }
    std::string getType() const override { return "V"; }
    bool isVoltageSource() const override { return true; }

    Complex sourceValue(double frequency) const {
        if (frequency == 0.0) {
            return {dcVoltage_, 0.0};
        }

        if (explicitDC_) {
            return {0.0, 0.0};
        }

        const double phaseRad = acPhaseDeg_ * M_PI / 180.0;
        const double magnitude = explicitAC_ ? acMagnitude_ : dcVoltage_;
        return std::polar(magnitude, phaseRad);
    }

private:
    double dcVoltage_;
    double acMagnitude_;
    double acPhaseDeg_;
    bool explicitAC_;
    bool explicitDC_;
};

struct SimulationResult {
    std::vector<Complex> x;
    std::vector<const Component*> voltageSources;
};

double parseValue(std::string text) {
    if (text.empty()) {
        throw std::runtime_error("Empty numeric value.");
    }

    while (!text.empty() && std::isspace(static_cast<unsigned char>(text.back()))) {
        text.pop_back();
    }
    while (!text.empty() && std::isspace(static_cast<unsigned char>(text.front()))) {
        text.erase(text.begin());
    }

    if (text.empty()) {
        throw std::runtime_error("Empty numeric value.");
    }

    double multiplier = 1.0;

    if (text.size() >= 3) {
        std::string suffix3 = text.substr(text.size() - 3);
        for (char& c : suffix3) {
            c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
        }
        if (suffix3 == "meg") {
            text.erase(text.size() - 3);
            return std::stod(text) * 1e6;
        }
    }

    const char suffix = text.back();
    switch (suffix) {
        case 'k': case 'K': multiplier = 1e3; break;
        case 'm': multiplier = 1e-3; break;
        case 'u': case 'U': multiplier = 1e-6; break;
        case 'n': case 'N': multiplier = 1e-9; break;
        case 'p': case 'P': multiplier = 1e-12; break;
        default: return std::stod(text);
    }

    text.pop_back();
    return std::stod(text) * multiplier;
}

std::string trimLeft(const std::string& s) {
    std::size_t i = 0;
    while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i]))) {
        ++i;
    }
    return s.substr(i);
}

std::shared_ptr<Circuit> parseNetlist(const std::string& netlist, double& frequency) {
    auto circuit = std::make_shared<Circuit>();
    frequency = 0.0;

    std::istringstream input(netlist);
    std::string line;

    while (std::getline(input, line)) {
        line = trimLeft(line);
        if (line.empty() || line[0] == '*') {
            continue;
        }

        // Ignore inline comments beginning with '*'.
        const std::size_t comment = line.find('*');
        if (comment != std::string::npos && comment > 0) {
            line = line.substr(0, comment);
        }

        std::istringstream ss(line);
        std::string name;
        ss >> name;
        if (name.empty()) {
            continue;
        }

        if (name == "FREQ" || name == "freq") {
            std::string freqText;
            ss >> freqText;
            if (freqText.empty()) {
                throw std::runtime_error("FREQ requires a numeric value.");
            }
            frequency = parseValue(freqText);
            continue;
        }

        int a = 0, b = 0;
        ss >> a >> b;
        if (!ss) {
            throw std::runtime_error("Invalid netlist line: " + line);
        }
        if (a < 0 || b < 0) {
            throw std::runtime_error("Node numbers cannot be negative: " + line);
        }

        const char type = static_cast<char>(std::toupper(
            static_cast<unsigned char>(name.front())));

        if (type == 'V') {
            std::string modeOrValue;
            ss >> modeOrValue;
            if (modeOrValue.empty()) {
                throw std::runtime_error("Voltage source requires a value: " + line);
            }

            std::string lower = modeOrValue;
            for (char& c : lower) {
                c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            }

            if (lower == "ac") {
                std::string ampText;
                ss >> ampText;
                if (ampText.empty()) {
                    throw std::runtime_error("AC source requires an amplitude: " + line);
                }
                const double amp = parseValue(ampText);
                double phase = 0.0;
                std::string phaseText;
                if (ss >> phaseText) {
                    phase = std::stod(phaseText);
                }

                circuit->addComponent(std::make_unique<GuiVoltageSource>(
                    name, a, b, 0.0, amp, phase, true, false));
            } else if (lower == "dc") {
                std::string dcText;
                ss >> dcText;
                if (dcText.empty()) {
                    throw std::runtime_error("DC source requires a value: " + line);
                }
                const double dc = parseValue(dcText);
                circuit->addComponent(std::make_unique<GuiVoltageSource>(
                    name, a, b, dc, 0.0, 0.0, false, true));
            } else {
                const double value = parseValue(modeOrValue);
                // Backward-compatible form: V1 1 0 5 means 5 V DC and also
                // acts as a 5 V, 0-degree AC source when an AC frequency is set.
                circuit->addComponent(std::make_unique<GuiVoltageSource>(
                    name, a, b, value, value, 0.0, false, false));
            }
        } else {
            std::string valueText;
            ss >> valueText;
            if (valueText.empty()) {
                throw std::runtime_error("Component requires a value: " + line);
            }
            const double value = parseValue(valueText);

            switch (type) {
                case 'R':
                    circuit->addComponent(std::make_unique<Resistor>(name, a, b, value));
                    break;
                case 'C':
                    circuit->addComponent(std::make_unique<Capacitor>(name, a, b, value));
                    break;
                case 'L':
                    circuit->addComponent(std::make_unique<Inductor>(name, a, b, value));
                    break;
                default:
                    throw std::runtime_error("Unknown component type in line: " + line);
            }
        }
    }

    if (circuit->getComponents().empty()) {
        throw std::runtime_error("No circuit components supplied.");
    }

    return circuit;
}

SimulationResult solve(const Circuit& circuit, double frequency) {
    const int N = circuit.getNumNodes();
    int M = 0;

    for (const auto& comp : circuit.getComponents()) {
        if (comp->isVoltageSource()) {
            ++M;
        }
    }

    Eigen::MatrixXcd A = Eigen::MatrixXcd::Zero(N + M, N + M);
    Eigen::VectorXcd b = Eigen::VectorXcd::Zero(N + M);

    int vIdx = N;
    std::vector<const Component*> voltageSources;
    voltageSources.reserve(M);

    for (const auto& comp : circuit.getComponents()) {
        const int nA = comp->getNodeA() - 1;
        const int nB = comp->getNodeB() - 1;

        if (comp->isVoltageSource()) {
            if (nA >= 0) {
                A(nA, vIdx) += 1.0;
                A(vIdx, nA) += 1.0;
            }
            if (nB >= 0) {
                A(nB, vIdx) -= 1.0;
                A(vIdx, nB) -= 1.0;
            }

            if (const auto* guiSource = dynamic_cast<const GuiVoltageSource*>(comp.get())) {
                b(vIdx) = guiSource->sourceValue(frequency);
            } else {
                // This path keeps the bridge compatible with ordinary uploaded
                // VoltageSource objects if one is ever inserted directly.
                b(vIdx) = (frequency == 0.0)
                    ? Complex(comp->getValue(), 0.0)
                    : Complex(comp->getValue(), 0.0);
            }

            voltageSources.push_back(comp.get());
            ++vIdx;
        } else {
            const Complex impedance = comp->getImpedance(frequency);
            if (std::abs(impedance) == 0.0) {
                throw std::runtime_error("Zero impedance encountered for " + comp->getName());
            }
            const Complex Y = 1.0 / impedance;

            if (nA >= 0) A(nA, nA) += Y;
            if (nB >= 0) A(nB, nB) += Y;
            if (nA >= 0 && nB >= 0) {
                A(nA, nB) -= Y;
                A(nB, nA) -= Y;
            }
        }
    }

    const Eigen::VectorXcd x = A.colPivHouseholderQr().solve(b);

    SimulationResult result;
    result.x.assign(x.data(), x.data() + x.size());
    result.voltageSources = std::move(voltageSources);
    return result;
}

double phaseDegrees(const Complex& z) {
    double phase = std::arg(z) * 180.0 / M_PI;
    if (std::abs(phase) < 1e-10) {
        phase = 0.0;
    }
    return phase;
}

std::string formatComplex(const Complex& z) {
    std::ostringstream out;
    out << std::fixed << std::setprecision(6)
        << "real=" << z.real()
        << " imag=" << z.imag()
        << " MAG=" << std::abs(z)
        << " PHASE=" << phaseDegrees(z) << " deg";
    return out.str();
}

} // namespace

std::string runBackendSimulationGUI(const std::string& netlist) {
    double frequency = 0.0;
    const auto circuit = parseNetlist(netlist, frequency);
    const SimulationResult result = solve(*circuit, frequency);

    std::ostringstream out;
    out << std::fixed << std::setprecision(6);
    out << "MiniSPICE GUI backend\n";
    out << "Frequency: " << frequency << " Hz\n\n";

    out << "Node Voltages:\n";
    for (int i = 0; i < circuit->getNumNodes(); ++i) {
        const Complex v = result.x[i];
        out << "Node " << (i + 1) << ": " << v.real()
            << " V  MAG=" << std::abs(v)
            << "  PHASE=" << phaseDegrees(v) << " deg\n";
    }

    out << "\nComponent Currents:\n";
    int vIdx = circuit->getNumNodes();
    for (const auto& comp : circuit->getComponents()) {
        Complex current{0.0, 0.0};

        if (comp->isVoltageSource()) {
            current = result.x[vIdx++];
        } else {
            const Complex vA = (comp->getNodeA() == 0)
                ? Complex{0.0, 0.0}
                : result.x[comp->getNodeA() - 1];
            const Complex vB = (comp->getNodeB() == 0)
                ? Complex{0.0, 0.0}
                : result.x[comp->getNodeB() - 1];
            current = (vA - vB) / comp->getImpedance(frequency);
        }

        out << "I(" << comp->getName() << "): "
            << formatComplex(current) << " A\n";
    }

    return out.str();
}
