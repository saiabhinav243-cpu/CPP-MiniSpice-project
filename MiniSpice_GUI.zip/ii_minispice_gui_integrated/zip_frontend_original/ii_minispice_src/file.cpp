#include <iostream>
#include <vector>
#include <complex>
#include <cmath>
#include <memory>
#include <sstream>
#include <cctype>

using namespace std;
#include<Eigen/Dense>
using Complex = complex<double>;
using Matrix = vector<vector<Complex>>;
using Vector = vector<Complex>;

class Component {
protected:
    string name;
    int nodeA, nodeB;
public:
    Component(string n, int a, int b) : name(n), nodeA(a), nodeB(b) {}
    virtual Complex getImpedance(double freq) const = 0;
    virtual double getValue() const = 0;
    virtual string getType() const = 0;
    virtual bool isVoltageSource() const { return false; }
    virtual Complex getSourceValue(double freq) const { return {0, 0}; }
    int getNodeA() const { return nodeA; }
    int getNodeB() const { return nodeB; }
};

class Resistor : public Component {
    double resistance;
public:
    Resistor(string n, int a, int b, double r) : Component(n, a, b), resistance(r) {}
    Complex getImpedance(double freq) const override { return {resistance, 0}; }
    string getType() const override { return "R"; }
    double getValue() const override { return resistance; }
};

class Capacitor : public Component {
    double capacitance;
public:
    Capacitor(string n, int a, int b, double c) : Component(n, a, b), capacitance(c) {}
    Complex getImpedance(double freq) const override {
        if (freq == 0.0) return {1e9, 0}; 
        return {0, -1.0 / (2 * M_PI * freq * capacitance)};
    }
    string getType() const override { return "C"; }
    double getValue() const override { return capacitance; }
};

class Inductor : public Component {
double inductance;
public:
Inductor(string n, int a, int b, double l) : Component (n, a, b), inductance(l) {}
Complex getImpedance(double freq) const override {
	if (freq == 0.0) return {1e-9, 0};
	return {0, (1.0*2*M_PI*freq*inductance)};
}
string getType() const override {return "L"; }
double getValue() const override { return inductance; }
};

class VoltageSource : public Component {
    double dcVoltage;
    double acMagnitude;
    double acPhaseDeg;
    bool hasExplicitAC;
public:
    VoltageSource(string n, int a, int b, double dcV,
                  double acMag = 0.0, double acPhase = 0.0,
                  bool explicitAC = false)
        : Component(n, a, b),
          dcVoltage(dcV),
          acMagnitude(acMag),
          acPhaseDeg(acPhase),
          hasExplicitAC(explicitAC) {}

    Complex getImpedance(double freq) const override { return {0, 0}; }
    string getType() const override { return "V"; }
    double getValue() const override { return dcVoltage; }
    bool isVoltageSource() const override { return true; }

    Complex getSourceValue(double freq) const override {
        if (freq == 0.0)
            return {dcVoltage, 0.0};

        // During AC analysis, use the explicitly supplied AC phasor.
        // For backward compatibility, a plain numeric voltage also acts
        // as a 0-degree AC amplitude.
        double magnitude = hasExplicitAC ? acMagnitude : dcVoltage;
        double phaseRad = acPhaseDeg * M_PI / 180.0;
        return std::polar(magnitude, phaseRad);
    }
};

class Circuit {
    vector<unique_ptr<Component>> components;
    int numNodes = 0;
public:
    void addComponent(unique_ptr<Component> comp) {
        if (comp->getNodeA() > numNodes){
	       	numNodes = comp->getNodeA();
	}
        if (comp->getNodeB() > numNodes){
	       	numNodes = comp->getNodeB();
	}
        components.push_back(move(comp));
    }
    int getNumNodes() const { return numNodes; }
    const auto& getComponents() const { return components; }
};

class NodalSimulator {
public:
    Eigen::VectorXcd solve(
        const Circuit& circuit,
        double freq
    ) {

        int N = circuit.getNumNodes();


        int M = 0;

        for (const auto& comp : circuit.getComponents()) {
            if (comp->isVoltageSource())
                M++;
        }


        Eigen::MatrixXcd A =
            Eigen::MatrixXcd::Zero(N + M, N + M);

        Eigen::VectorXcd b =
            Eigen::VectorXcd::Zero(N + M);


        int v_idx = N;

        for (const auto& comp : circuit.getComponents()) {

            int nA = comp->getNodeA() - 1;
            int nB = comp->getNodeB() - 1;


            if (comp->isVoltageSource()) {

                if (nA >= 0) {
                    A(nA, v_idx) += 1.0;
                    A(v_idx, nA) += 1.0;
                }

                if (nB >= 0) {
                    A(nB, v_idx) -= 1.0;
                    A(v_idx, nB) -= 1.0;
                }

                b(v_idx) = comp->getSourceValue(freq);

                v_idx++;
            }


            else {

                complex<double> Y =
                    1.0 / comp->getImpedance(freq);

                if (nA >= 0)
                    A(nA, nA) += Y;

                if (nB >= 0)
                    A(nB, nB) += Y;

                if (nA >= 0 && nB >= 0) {
                    A(nA, nB) -= Y;
                    A(nB, nA) -= Y;
                }
            }
        }

        // Solve A*x = b
        return A.colPivHouseholderQr().solve(b);
    }
};
 
int main() {
    // Read a netlist from stdin. Supports a single frequency per run.
    // Format:
    //   Rname nodeA nodeB value
    //   Cname nodeA nodeB value
    //   Lname nodeA nodeB value
    //   Vname nodeA nodeB value
    //   FREQ frequency
    // Values support suffixes: k, meg, m, u, n, p.

    auto parseValue = [](string text) -> double {
        if (text.empty()) return 0.0;
        double multiplier = 1.0;
        if (text.size() >= 3) {
            string suffix3 = text.substr(text.size() - 3);
            for (char &c : suffix3) c = static_cast<char>(tolower(c));
            if (suffix3 == "meg") {
                multiplier = 1e6;
                text.erase(text.size() - 3);
                return stod(text) * multiplier;
            }
        }
        char suffix = text.back();
        switch (suffix) {
            case 'k': case 'K': multiplier = 1e3; text.pop_back(); break;
            case 'm': multiplier = 1e-3; text.pop_back(); break;
            case 'u': case 'U': multiplier = 1e-6; text.pop_back(); break;
            case 'n': case 'N': multiplier = 1e-9; text.pop_back(); break;
            case 'p': case 'P': multiplier = 1e-12; text.pop_back(); break;
            default: break;
        }
        return stod(text) * multiplier;
    };

    Circuit myCircuit;
    double frequency = 0.0;
    string line;

    while (getline(cin, line)) {
        if (line.empty() || line[0] == '*') continue;

        stringstream ss(line);
        string name;
        ss >> name;
        if (name.empty()) continue;

        if (name == "FREQ" || name == "freq") {
            string value;
            ss >> value;
            frequency = parseValue(value);
            continue;
        }

        int a, b;
        ss >> a >> b;
        if (!ss) continue;

        char type = static_cast<char>(toupper(name[0]));

        if (type == 'V') {
            // Voltage source formats:
            //   V1 1 0 5          -> DC 5, and 5 V AC amplitude (legacy)
            //   V1 1 0 DC 5       -> DC 5, no explicit AC source
            //   V1 1 0 AC 1       -> AC 1∠0°
            //   V1 1 0 AC 1 90    -> AC 1∠90°
            string modeOrValue;
            ss >> modeOrValue;
            if (!ss) continue;

            string lower = modeOrValue;
            for (char &c : lower) c = static_cast<char>(tolower(c));

            if (lower == "ac") {
                string ampText, phaseText;
                ss >> ampText;
                if (ampText.empty()) continue;
                double amp = parseValue(ampText);
                double phase = 0.0;
                if (ss >> phaseText) phase = stod(phaseText);

                myCircuit.addComponent(
                    make_unique<VoltageSource>(name, a, b, 0.0, amp, phase, true));
            }
            else if (lower == "dc") {
                string dcText;
                ss >> dcText;
                if (dcText.empty()) continue;
                double dc = parseValue(dcText);

                myCircuit.addComponent(
                    make_unique<VoltageSource>(name, a, b, dc, 0.0, 0.0, true));
            }
            else {
                double v = parseValue(modeOrValue);
                myCircuit.addComponent(
                    make_unique<VoltageSource>(name, a, b, v));
            }
        }
        else {
            string value;
            ss >> value;
            if (!ss) continue;

            double v = parseValue(value);

            if (type == 'R')
                myCircuit.addComponent(make_unique<Resistor>(name, a, b, v));
            else if (type == 'C')
                myCircuit.addComponent(make_unique<Capacitor>(name, a, b, v));
            else if (type == 'L')
                myCircuit.addComponent(make_unique<Inductor>(name, a, b, v));
        }
    }

    if (myCircuit.getComponents().empty()) {
        cerr << "No circuit components supplied.\n";
        return 1;
    }

    NodalSimulator simulator;
    Eigen::VectorXcd results = simulator.solve(myCircuit, frequency);

    // Machine-readable node results for the GUI, plus human-readable output.
    for (int i = 0; i < myCircuit.getNumNodes(); ++i) {
        double magnitude = abs(results[i]);
        double phase = arg(results[i]) * 180.0 / M_PI;
        cout << "Node " << (i + 1) << ": " << real(results[i])
             << " V  MAG=" << magnitude << "  PHASE=" << phase << " deg\n";
    }

    int voltageSourceIndex = myCircuit.getNumNodes();
    for (const auto& comp : myCircuit.getComponents()) {
        if (comp->isVoltageSource()) {
            cout << "I_" << comp->getType() << ": "
                 << real(results[voltageSourceIndex]) << " A\n";
            ++voltageSourceIndex;
        }
    }

    return 0;
}
