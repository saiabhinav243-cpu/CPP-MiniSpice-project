MiniSPICE - AC Sweep + AC Steady State
======================================

This version adds a third analysis mode:
  1. DC
  2. AC Sweep
  3. AC Steady State

AC Sweep:
  Plots magnitude or phase against logarithmic frequency.

AC Steady State:
  Solves the circuit at one selected frequency, reads the complex node
  phasor from the MNA backend, and plots the actual sinusoidal steady-state
  waveform:

      v(t) = |V| cos(2*pi*f*t + phase)

Netlist voltage source syntax:
  V1 1 0 1          -> 1 V source; also acts as 1 V AC amplitude in AC analysis
  V1 1 0 AC 1 0     -> 1 V AC source at 0 degrees
  V1 1 0 AC 1 90    -> 1 V AC source at +90 degrees
  V1 1 0 DC 5       -> DC-only 5 V source

Build:
  cd MiniSPICE_frontend
  cmake -S . -B build
  cmake --build build -j$(nproc)
  ./build/MiniSPICE

Dependencies:
  Qt6 Widgets
  Eigen3

Important:
  The Qt GUI executable expects the backend executable to be named
  MiniSPICEBackend and located beside it. CMake creates it automatically.
