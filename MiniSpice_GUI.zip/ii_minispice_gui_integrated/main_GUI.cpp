#include <QApplication>
#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QFrame>
#include <QScrollArea>
#include <QMessageBox>
#include <QPainter>
#include <QPainterPath>
#include <QPen>
#include <QVector>
#include <QRegularExpression>
#include <cmath>
#include <algorithm>

#include "gui_backend_bridge.h"

class GraphWidget : public QWidget
{
public:
    GraphWidget(QWidget *parent = nullptr) : QWidget(parent)
    {
        setMinimumHeight(300);
        setAutoFillBackground(true);
        setStyleSheet("background:white; border:1px solid #d1d5db;");
    }

    void setData(const QVector<double>& x, const QVector<double>& y,
                 const QString& title, const QString& yLabel,
                 const QString& xLabel, bool logX)
    {
        m_x = x;
        m_y = y;
        m_title = title;
        m_yLabel = yLabel;
        m_xLabel = xLabel;
        m_logX = logX;
        update();
    }

    void clearData()
    {
        m_x.clear();
        m_y.clear();
        update();
    }

protected:
    void paintEvent(QPaintEvent *) override
    {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing);
        p.fillRect(rect(), Qt::white);

        if (m_x.size() < 2 || m_y.size() < 2) {
            p.setPen(QColor("#9ca3af"));
            p.drawText(rect(), Qt::AlignCenter, "Run an analysis to see the graph");
            return;
        }

        const int left = 78;
        const int right = 24;
        const int top = 42;
        const int bottom = 56;
        QRect plot(left, top, width() - left - right, height() - top - bottom);
        if (plot.width() <= 0 || plot.height() <= 0) return;

        double xmin = *std::min_element(m_x.begin(), m_x.end());
        double xmax = *std::max_element(m_x.begin(), m_x.end());
        double ymin = *std::min_element(m_y.begin(), m_y.end());
        double ymax = *std::max_element(m_y.begin(), m_y.end());

        if (m_logX) {
            xmin = std::max(xmin, 1e-30);
            xmax = std::max(xmax, xmin * 10.0);
        } else {
            if (xmax <= xmin) xmax = xmin + 1.0;
        }

        if (std::abs(ymax - ymin) < 1e-12) {
            double pad = std::max(1.0, std::abs(ymax) * 0.1);
            ymax += pad;
            ymin -= pad;
        } else {
            const double pad = (ymax - ymin) * 0.08;
            ymin -= pad;
            ymax += pad;
        }

        // Grid.
        p.setPen(QPen(QColor("#e5e7eb"), 1));
        for (int i = 0; i <= 5; ++i) {
            int y = plot.bottom() - i * plot.height() / 5;
            p.drawLine(plot.left(), y, plot.right(), y);
        }

        if (m_logX) {
            double firstDecade = std::pow(10.0, std::floor(std::log10(xmin)));
            for (double f = firstDecade; f <= xmax * 1.000001; f *= 10.0) {
                for (int k = 1; k < 10; ++k) {
                    double fx = f * k;
                    if (fx < xmin || fx > xmax) continue;
                    double t = (std::log10(fx) - std::log10(xmin)) /
                               (std::log10(xmax) - std::log10(xmin));
                    int x = plot.left() + static_cast<int>(t * plot.width());
                    p.drawLine(x, plot.top(), x, plot.bottom());
                }
                if (f > xmax / 10.0) break;
            }
        } else {
            for (int i = 0; i <= 5; ++i) {
                double xValue = xmin + (xmax - xmin) * i / 5.0;
                int x = plot.left() + i * plot.width() / 5;
                Q_UNUSED(xValue);
                p.drawLine(x, plot.top(), x, plot.bottom());
            }
        }

        p.setPen(QPen(QColor("#374151"), 2));
        p.drawLine(plot.left(), plot.bottom(), plot.right(), plot.bottom());
        p.drawLine(plot.left(), plot.top(), plot.left(), plot.bottom());

        // Curve.
        QPainterPath path;
        for (int i = 0; i < m_x.size(); ++i) {
            double tx;
            if (m_logX) {
                tx = (std::log10(std::max(m_x[i], xmin)) - std::log10(xmin)) /
                     (std::log10(xmax) - std::log10(xmin));
            } else {
                tx = (m_x[i] - xmin) / (xmax - xmin);
            }
            double ty = (m_y[i] - ymin) / (ymax - ymin);
            QPointF pt(plot.left() + tx * plot.width(),
                       plot.bottom() - ty * plot.height());
            if (i == 0) path.moveTo(pt);
            else path.lineTo(pt);
        }

        p.setPen(QPen(QColor("#2563eb"), 2.5));
        p.drawPath(path);

        // Title.
        p.setPen(QColor("#111827"));
        QFont titleFont = p.font();
        titleFont.setBold(true);
        titleFont.setPointSize(11);
        p.setFont(titleFont);
        p.drawText(QRect(0, 8, width(), 24), Qt::AlignCenter, m_title);

        // Y ticks.
        QFont normal = p.font();
        normal.setBold(false);
        normal.setPointSize(9);
        p.setFont(normal);
        for (int i = 0; i <= 5; ++i) {
            double yValue = ymin + (ymax - ymin) * i / 5.0;
            int y = plot.bottom() - i * plot.height() / 5;
            p.drawText(QRect(0, y - 10, left - 8, 20),
                       Qt::AlignRight | Qt::AlignVCenter,
                       QString::number(yValue, 'g', 4));
        }

        // X ticks.
        if (m_logX) {
            double logMin = std::log10(xmin);
            double logMax = std::log10(xmax);
            int firstPower = static_cast<int>(std::ceil(logMin));
            int lastPower = static_cast<int>(std::floor(logMax));
            for (int power = firstPower; power <= lastPower; ++power) {
                double f = std::pow(10.0, power);
                double tx = (std::log10(f) - logMin) / (logMax - logMin);
                int x = plot.left() + static_cast<int>(tx * plot.width());
                p.drawText(QRect(x - 45, plot.bottom() + 7, 90, 20),
                           Qt::AlignCenter, formatFrequency(f));
            }
        } else {
            for (int i = 0; i <= 5; ++i) {
                double xValue = xmin + (xmax - xmin) * i / 5.0;
                int x = plot.left() + i * plot.width() / 5;
                p.drawText(QRect(x - 45, plot.bottom() + 7, 90, 20),
                           Qt::AlignCenter, formatNumber(xValue));
            }
        }

        p.save();
        p.translate(15, plot.center().y());
        p.rotate(-90);
        p.drawText(QRect(-plot.height()/2, -10, plot.height(), 20),
                   Qt::AlignCenter, m_yLabel);
        p.restore();

        p.drawText(QRect(plot.left(), height() - 25, plot.width(), 20),
                   Qt::AlignCenter, m_xLabel);
    }

private:
    QString formatFrequency(double f) const
    {
        if (f >= 1e9) return QString::number(f / 1e9, 'g', 3) + "G";
        if (f >= 1e6) return QString::number(f / 1e6, 'g', 3) + "M";
        if (f >= 1e3) return QString::number(f / 1e3, 'g', 3) + "k";
        if (f >= 1.0) return QString::number(f, 'g', 3);
        if (f >= 1e-3) return QString::number(f * 1e3, 'g', 3) + "m";
        if (f >= 1e-6) return QString::number(f * 1e6, 'g', 3) + "u";
        return QString::number(f, 'g', 3);
    }

    QString formatNumber(double x) const
    {
        if (std::abs(x) >= 1.0) return QString::number(x, 'g', 5);
        return QString::number(x, 'e', 3);
    }

    QVector<double> m_x;
    QVector<double> m_y;
    QString m_title;
    QString m_yLabel;
    QString m_xLabel;
    bool m_logX = false;
};

class MiniSpiceWindow : public QMainWindow
{
public:
    MiniSpiceWindow()
    {
        setWindowTitle("MiniSPICE");
        resize(1250, 950);

        auto *central = new QWidget;
        auto *mainLayout = new QVBoxLayout(central);
        mainLayout->setContentsMargins(16, 16, 16, 16);
        mainLayout->setSpacing(10);

        auto *title = new QLabel("MiniSPICE");
        title->setStyleSheet("font-size: 26px; font-weight: 700;");
        auto *subtitle = new QLabel("C++ MNA circuit simulator");
        subtitle->setStyleSheet("color: #777;");

        auto *header = new QHBoxLayout;
        auto *analysisLabel = new QLabel("Analysis:");
        auto *analysis = new QComboBox;
        analysis->addItems({"DC", "AC Sweep", "AC Steady State"});
        analysis->setFixedWidth(160);

        auto *runButton = new QPushButton("▶  Run Simulation");
        runButton->setMinimumHeight(38);
        runButton->setStyleSheet(
            "QPushButton { background:#2563eb; color:white; border-radius:6px; "
            "padding:8px 18px; font-weight:600; }"
            "QPushButton:hover { background:#1d4ed8; }");

        header->addWidget(title);
        header->addWidget(subtitle);
        header->addStretch();
        header->addWidget(analysisLabel);
        header->addWidget(analysis);
        header->addWidget(runButton);
        mainLayout->addLayout(header);

        auto *content = new QHBoxLayout;
        content->setSpacing(10);

        auto *paletteBox = new QGroupBox("Components");
        paletteBox->setFixedWidth(180);
        auto *palette = new QVBoxLayout(paletteBox);

        auto makeButton = [&](const QString &text) {
            auto *b = new QPushButton(text);
            b->setMinimumHeight(40);
            palette->addWidget(b);
            return b;
        };

        auto *resistorButton = makeButton("R   Resistor");
        auto *capacitorButton = makeButton("C   Capacitor");
        auto *inductorButton = makeButton("L   Inductor");
        auto *voltageButton = makeButton("V   Voltage Source");
        palette->addStretch();
        content->addWidget(paletteBox);

        auto *canvasBox = new QGroupBox("Schematic");
        auto *canvasLayout = new QVBoxLayout(canvasBox);
        auto *canvas = new QFrame;
        canvas->setMinimumSize(500, 280);
        canvas->setFrameShape(QFrame::StyledPanel);
        canvas->setStyleSheet("QFrame { background:#ffffff; border:1px solid #d1d5db; }");
        auto *canvasInner = new QVBoxLayout(canvas);
        auto *canvasText = new QLabel(
            "Schematic editor prototype\n\n"
            "Use the component buttons and netlist editor to define the circuit.");
        canvasText->setAlignment(Qt::AlignCenter);
        canvasText->setStyleSheet("color:#9ca3af; font-size:15px;");
        canvasInner->addWidget(canvasText);
        canvasLayout->addWidget(canvas);
        content->addWidget(canvasBox, 1);

        auto *propertiesBox = new QGroupBox("Component Template");
        propertiesBox->setFixedWidth(250);
        auto *properties = new QGridLayout(propertiesBox);

        properties->addWidget(new QLabel("Name:"), 0, 0);
        auto *componentName = new QLineEdit("R1");
        properties->addWidget(componentName, 0, 1);

        properties->addWidget(new QLabel("Node A:"), 1, 0);
        auto *nodeA = new QLineEdit("1");
        properties->addWidget(nodeA, 1, 1);

        properties->addWidget(new QLabel("Node B:"), 2, 0);
        auto *nodeB = new QLineEdit("2");
        properties->addWidget(nodeB, 2, 1);

        properties->addWidget(new QLabel("Value:"), 3, 0);
        auto *value = new QLineEdit("100");
        properties->addWidget(value, 3, 1);

        properties->addWidget(new QLabel("Unit:"), 4, 0);
        auto *unit = new QComboBox;
        unit->addItems({"Ω", "F", "H", "V"});
        properties->addWidget(unit, 4, 1);

        auto *addButton = new QPushButton("Add to Netlist");
        properties->addWidget(addButton, 5, 0, 1, 2);
        properties->setRowStretch(6, 1);
        content->addWidget(propertiesBox);
        mainLayout->addLayout(content, 1);

        auto *bottom = new QHBoxLayout;

        auto *netlistBox = new QGroupBox("Circuit Input (editable)");
        auto *netlistLayout = new QVBoxLayout(netlistBox);
        auto *netlist = new QTextEdit;
        netlist->setPlainText(
            "V1 1 0 1\n"
            "R1 1 2 1k\n"
            "C1 2 0 1u\n");
        netlist->setToolTip(
            "One component per line: NAME NODE_A NODE_B VALUE\n"
            "Examples: R1 1 2 1k, C1 2 0 1u, L1 2 0 10m, V1 1 0 1\n"
            "For AC sources: V1 1 0 AC 1 0\n"
            "For DC-only sources: V1 1 0 DC 5");
        netlistLayout->addWidget(netlist);

        auto *outputBox = new QGroupBox("Simulation Output");
        auto *outputLayout = new QVBoxLayout(outputBox);
        auto *output = new QTextEdit;
        output->setReadOnly(true);
        output->setPlainText("Ready. Choose DC, AC Sweep, or AC Steady State and press Run Simulation.");
        outputLayout->addWidget(output);

        bottom->addWidget(netlistBox, 1);
        bottom->addWidget(outputBox, 1);
        mainLayout->addLayout(bottom);

        // AC sweep controls.
        auto *sweepBox = new QGroupBox("AC Sweep Settings");
        auto *sweepLayout = new QGridLayout(sweepBox);
        sweepLayout->addWidget(new QLabel("Start (Hz):"), 0, 0);
        auto *startFreq = new QLineEdit("10");
        sweepLayout->addWidget(startFreq, 0, 1);

        sweepLayout->addWidget(new QLabel("Stop (Hz):"), 0, 2);
        auto *stopFreq = new QLineEdit("100000");
        sweepLayout->addWidget(stopFreq, 0, 3);

        sweepLayout->addWidget(new QLabel("Points:"), 0, 4);
        auto *points = new QLineEdit("100");
        sweepLayout->addWidget(points, 0, 5);

        sweepLayout->addWidget(new QLabel("Plot node:"), 0, 6);
        auto *plotNode = new QLineEdit("2");
        sweepLayout->addWidget(plotNode, 0, 7);

        sweepLayout->addWidget(new QLabel("Y-axis:"), 0, 8);
        auto *plotMode = new QComboBox;
        plotMode->addItems({"Magnitude (V)", "Phase (deg)"});
        sweepLayout->addWidget(plotMode, 0, 9);

        mainLayout->addWidget(sweepBox);

        // AC steady-state controls.
        auto *steadyBox = new QGroupBox("AC Steady State Settings");
        auto *steadyLayout = new QGridLayout(steadyBox);

        steadyLayout->addWidget(new QLabel("Frequency (Hz):"), 0, 0);
        auto *steadyFreq = new QLineEdit("1000");
        steadyLayout->addWidget(steadyFreq, 0, 1);

        steadyLayout->addWidget(new QLabel("Cycles:"), 0, 2);
        auto *cycles = new QLineEdit("3");
        steadyLayout->addWidget(cycles, 0, 3);

        steadyLayout->addWidget(new QLabel("Points / cycle:"), 0, 4);
        auto *pointsPerCycle = new QLineEdit("300");
        steadyLayout->addWidget(pointsPerCycle, 0, 5);

        steadyLayout->addWidget(new QLabel("Plot node:"), 0, 6);
        auto *steadyNode = new QLineEdit("2");
        steadyLayout->addWidget(steadyNode, 0, 7);

        steadyLayout->addWidget(new QLabel("Y-axis:"), 0, 8);
        auto *steadyMode = new QComboBox;
        steadyMode->addItems({"Voltage (V)", "Magnitude (V)", "Phase (deg)"});
        steadyLayout->addWidget(steadyMode, 0, 9);

        mainLayout->addWidget(steadyBox);

        auto *graphBox = new QGroupBox("AC Response");
        auto *graphLayout = new QVBoxLayout(graphBox);
        auto *graph = new GraphWidget;
        graph->setMinimumHeight(420);
        graphLayout->addWidget(graph);
        mainLayout->addWidget(graphBox);

        // Put the entire UI inside a scroll area so the lower controls and
        // graph remain reachable on smaller screens.
        auto *scrollArea = new QScrollArea;
        scrollArea->setWidgetResizable(true);
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea->setWidget(central);
        setCentralWidget(scrollArea);

        auto insertComponent = [componentName, value, unit, canvasText](
            const QString &type, const QString &defaultName,
            const QString &defaultValue, const QString &defaultUnit) {
            componentName->setText(defaultName);
            value->setText(defaultValue);
            int idx = unit->findText(defaultUnit);
            if (idx >= 0) unit->setCurrentIndex(idx);
            canvasText->setText("Selected: " + type +
                                "\n\nSet nodes/value on the right, then click Add to Netlist.");
        };

        connect(resistorButton, &QPushButton::clicked, this, [insertComponent]() {
            insertComponent("Resistor", "R1", "100", "Ω");
        });
        connect(capacitorButton, &QPushButton::clicked, this, [insertComponent]() {
            insertComponent("Capacitor", "C1", "10u", "F");
        });
        connect(inductorButton, &QPushButton::clicked, this, [insertComponent]() {
            insertComponent("Inductor", "L1", "10m", "H");
        });
        connect(voltageButton, &QPushButton::clicked, this, [insertComponent]() {
            insertComponent("Voltage Source", "V1", "1", "V");
        });

        connect(addButton, &QPushButton::clicked, this, [=]() {
            QString name = componentName->text().trimmed();
            QString a = nodeA->text().trimmed();
            QString b = nodeB->text().trimmed();
            QString val = value->text().trimmed();

            if (name.isEmpty() || a.isEmpty() || b.isEmpty() || val.isEmpty()) {
                QMessageBox::warning(this, "Invalid input", "Fill in name, nodes and value.");
                return;
            }
            netlist->append(name + " " + a + " " + b + " " + val);
        });

        auto updateAnalysisPanels = [analysis, sweepBox, steadyBox, graphBox]() {
            const QString mode = analysis->currentText();
            const bool sweep = (mode == "AC Sweep");
            const bool steady = (mode == "AC Steady State");
            sweepBox->setEnabled(sweep);
            steadyBox->setEnabled(steady);
            graphBox->setEnabled(sweep || steady);
        };

        connect(analysis, &QComboBox::currentTextChanged, this,
                [updateAnalysisPanels](const QString &) { updateAnalysisPanels(); });
        updateAnalysisPanels();

        connect(runButton, &QPushButton::clicked, this, [=]() {
            const QString mode = analysis->currentText();

            if (mode == "DC") {
                try {
                    std::string result = runBackendSimulationGUI(netlist->toPlainText().toStdString());
                    output->setPlainText(QString::fromStdString(result));
                    graph->clearData();
                } catch (const std::exception& e) {
                    output->setPlainText(QString("Simulation failed:\n\n%1").arg(e.what()));
                }
                return;
            }

            if (mode == "AC Sweep") {
                bool okStart = false, okStop = false, okPoints = false, okNode = false;
                double fStart = startFreq->text().toDouble(&okStart);
                double fStop = stopFreq->text().toDouble(&okStop);
                int nPoints = points->text().toInt(&okPoints);
                int node = plotNode->text().toInt(&okNode);

                if (!okStart || !okStop || !okPoints || !okNode ||
                    fStart <= 0 || fStop <= fStart || nPoints < 2 || node < 1) {
                    QMessageBox::warning(this, "Invalid AC sweep",
                        "Use start > 0, stop > start, points >= 2, and a positive node number.");
                    return;
                }

                QVector<double> frequencies;
                QVector<double> values;
                QString combinedOutput;
                combinedOutput += QString("AC sweep: %1 Hz → %2 Hz, %3 points\n")
                    .arg(fStart).arg(fStop).arg(nPoints);
                combinedOutput += QString("Plotting node %1 (%2)\n\n")
                    .arg(node).arg(plotMode->currentText());

                for (int i = 0; i < nPoints; ++i) {
                    double t = static_cast<double>(i) / static_cast<double>(nPoints - 1);
                    double freq = std::pow(10.0,
                        std::log10(fStart) + t * (std::log10(fStop) - std::log10(fStart)));

                    QString sweepNetlist = netlist->toPlainText();
                    sweepNetlist += QString("\nFREQ %1\n").arg(QString::number(freq, 'g', 12));

                    try {
                        std::string raw = runBackendSimulationGUI(sweepNetlist.toStdString());
                        QString text = QString::fromStdString(raw);
                        QRegularExpression re(
                            QStringLiteral("Node\\s+(\\d+)\\s*:\\s*[-+0-9.eE]+\\s*V\\s+MAG=([-+0-9.eE]+)\\s+PHASE=([-+0-9.eE]+)"));
                        QRegularExpressionMatchIterator it = re.globalMatch(text);
                        bool found = false;
                        double magnitude = 0.0;
                        double phase = 0.0;
                        while (it.hasNext()) {
                            auto match = it.next();
                            if (match.captured(1).toInt() == node) {
                                magnitude = match.captured(2).toDouble();
                                phase = match.captured(3).toDouble();
                                found = true;
                                break;
                            }
                        }

                        if (!found) {
                            output->setPlainText("AC sweep failed: node " + QString::number(node) +
                                                " was not found in backend output.\n\n" + text);
                            return;
                        }

                        frequencies.append(freq);
                        values.append(plotMode->currentIndex() == 0 ? magnitude : phase);
                    } catch (const std::exception& e) {
                        output->setPlainText(QString("AC sweep failed at %1 Hz:\n\n%2")
                            .arg(freq).arg(e.what()));
                        return;
                    }
                }

                for (int i = 0; i < frequencies.size(); ++i) {
                    combinedOutput += QString("%1 Hz    %2\n")
                        .arg(QString::number(frequencies[i], 'g', 8), -16)
                        .arg(QString::number(values[i], 'g', 8));
                }

                output->setPlainText(combinedOutput);
                QString graphTitle = QString("Node %1 AC Response — %2")
                    .arg(node).arg(plotMode->currentText());
                graph->setData(frequencies, values, graphTitle,
                               plotMode->currentIndex() == 0 ? "Magnitude (V)" : "Phase (degrees)",
                               "Frequency (Hz, logarithmic scale)", true);
                return;
            }

            // AC Steady State.
            bool okFreq = false, okCycles = false, okPpc = false, okNode = false;
            double freq = steadyFreq->text().toDouble(&okFreq);
            double nCycles = cycles->text().toDouble(&okCycles);
            int ppc = pointsPerCycle->text().toInt(&okPpc);
            int node = steadyNode->text().toInt(&okNode);

            if (!okFreq || !okCycles || !okPpc || !okNode ||
                freq <= 0 || nCycles <= 0 || ppc < 10 || ppc > 20000 || node < 1) {
                QMessageBox::warning(this, "Invalid AC steady-state settings",
                    "Use frequency > 0, cycles > 0, points/cycle between 10 and 20000, and a positive node number.");
                return;
            }

            QString steadyNetlist = netlist->toPlainText();
            steadyNetlist += QString("\nFREQ %1\n").arg(QString::number(freq, 'g', 12));

            try {
                QString text = QString::fromStdString(
                    runBackendSimulationGUI(steadyNetlist.toStdString()));

                QRegularExpression re(
                    QStringLiteral("Node\\s+(\\d+)\\s*:\\s*[-+0-9.eE]+\\s*V\\s+MAG=([-+0-9.eE]+)\\s+PHASE=([-+0-9.eE]+)"));
                QRegularExpressionMatchIterator it = re.globalMatch(text);
                bool found = false;
                double magnitude = 0.0;
                double phaseDeg = 0.0;

                while (it.hasNext()) {
                    auto match = it.next();
                    if (match.captured(1).toInt() == node) {
                        magnitude = match.captured(2).toDouble();
                        phaseDeg = match.captured(3).toDouble();
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    output->setPlainText("AC steady-state failed: node " + QString::number(node) +
                                        " was not found in backend output.\n\n" + text);
                    return;
                }

                QVector<double> time;
                QVector<double> values;
                const int totalPoints = std::max(2, static_cast<int>(std::ceil(nCycles * ppc)) + 1);
                const double period = 1.0 / freq;
                const double phaseRad = phaseDeg * M_PI / 180.0;
                const double totalTime = nCycles * period;

                for (int i = 0; i < totalPoints; ++i) {
                    double t = totalTime * static_cast<double>(i) /
                               static_cast<double>(totalPoints - 1);
                    double voltage = magnitude * std::cos(2.0 * M_PI * freq * t + phaseRad);
                    time.append(t);
                    values.append(voltage);
                }

                QString combinedOutput;
                combinedOutput += QString("AC steady state\n");
                combinedOutput += QString("Frequency: %1 Hz\n").arg(freq);
                combinedOutput += QString("Node: %1\n").arg(node);
                combinedOutput += QString("Phasor magnitude: %1 V\n").arg(magnitude, 0, 'g', 10);
                combinedOutput += QString("Phasor phase: %1 deg\n").arg(phaseDeg, 0, 'g', 10);
                combinedOutput += QString("Peak voltage: %1 V\n").arg(magnitude, 0, 'g', 10);
                combinedOutput += QString("Peak-to-peak voltage: %1 V\n").arg(2.0 * magnitude, 0, 'g', 10);
                combinedOutput += QString("Period: %1 s\n").arg(period, 0, 'g', 10);
                combinedOutput += QString("Displayed cycles: %1\n").arg(nCycles);
                combinedOutput += "\nBackend phasor result:\n" + text;

                output->setPlainText(combinedOutput);

                QString graphTitle;
                if (steadyMode->currentIndex() == 0) {
                    graphTitle = QString("Node %1 AC Steady State — %2 Hz")
                        .arg(node).arg(freq, 0, 'g', 6);
                    graph->setData(time, values, graphTitle, "Voltage (V)",
                                   "Time (s)", false);
                } else if (steadyMode->currentIndex() == 1) {
                    QVector<double> magnitudeLine;
                    magnitudeLine.reserve(time.size());
                    for (int i = 0; i < time.size(); ++i)
                        magnitudeLine.append(magnitude);
                    graphTitle = QString("Node %1 AC Magnitude — %2 Hz")
                        .arg(node).arg(freq, 0, 'g', 6);
                    graph->setData(time, magnitudeLine, graphTitle, "Magnitude (V)",
                                   "Time (s)", false);
                } else {
                    QVector<double> phaseLine;
                    phaseLine.reserve(time.size());
                    for (int i = 0; i < time.size(); ++i)
                        phaseLine.append(phaseDeg);
                    graphTitle = QString("Node %1 AC Phase — %2 Hz")
                        .arg(node).arg(freq, 0, 'g', 6);
                    graph->setData(time, phaseLine, graphTitle, "Phase (degrees)",
                                   "Time (s)", false);
                }
            } catch (const std::exception& e) {
                output->setPlainText(QString("AC steady-state simulation failed:\n\n%1").arg(e.what()));
            }
        });
    }
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    MiniSpiceWindow window;
    window.show();
    return app.exec();
}
