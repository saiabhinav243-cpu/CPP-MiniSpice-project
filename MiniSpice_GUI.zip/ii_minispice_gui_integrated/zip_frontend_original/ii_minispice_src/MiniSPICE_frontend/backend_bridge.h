#pragma once
#include <string>

std::string runBackendSimulation(const std::string& netlist);
