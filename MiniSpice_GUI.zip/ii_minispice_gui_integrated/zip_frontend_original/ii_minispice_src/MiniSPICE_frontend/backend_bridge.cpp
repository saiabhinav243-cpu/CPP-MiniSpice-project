#include "backend_bridge.h"
#include <QCoreApplication>
#include <QProcess>
#include <stdexcept>

std::string runBackendSimulation(const std::string& netlist)
{
    QProcess process;

    const QString backend = QCoreApplication::applicationDirPath() + "/MiniSPICEBackend";
    process.start(backend, {}, QIODevice::ReadWrite);

    if (!process.waitForStarted(3000))
        throw std::runtime_error(("Could not start backend: " + process.errorString()).toStdString());

    process.write(QByteArray::fromStdString(netlist));
    process.closeWriteChannel();

    if (!process.waitForFinished(10000)) {
        process.kill();
        throw std::runtime_error("Backend timed out.");
    }

    if (process.exitStatus() != QProcess::NormalExit || process.exitCode() != 0) {
        throw std::runtime_error(QString("Backend failed: %1")
            .arg(QString::fromLocal8Bit(process.readAllStandardError())).toStdString());
    }

    return process.readAllStandardOutput().toStdString();
}
