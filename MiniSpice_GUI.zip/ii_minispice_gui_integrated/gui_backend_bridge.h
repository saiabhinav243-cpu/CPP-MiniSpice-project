#pragma once

#include <string>

// Runs the GUI netlist through the simulator implementation used by the
// existing project and returns machine-readable + human-readable output.
std::string runBackendSimulationGUI(const std::string& netlist);
